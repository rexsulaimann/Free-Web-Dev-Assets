---
name: Header and Footer templates
about: Make your open-source contribution
title: ''
labels: Open-Source
assignees: ''

---

# Contribution in open-source is not easy and not hard.

This repository is created to get a bunch of designs of headers and footers.

# How you can contribute?

- Fork this repository
- Create a folder inside the templates folder
- Make all the files you code inside the folder you created
- Create a text file inside your folder and write your name in it
- Create pull request
- Done! we will merge your folder

And yes, your contribution is done.
