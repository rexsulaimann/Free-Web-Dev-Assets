This is a simple header created entirely using Tailwind CSS and minimum usage of CSS.
Created by R0Y4L23 (https://github.com/R0Y4L23)