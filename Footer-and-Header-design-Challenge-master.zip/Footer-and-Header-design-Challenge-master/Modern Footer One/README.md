<p align="center">
© Adam Jones, <a href="https://www.ayeteejay.com">Ayeteejay.com</a>
<p align="center">
<img src="https://www.ayeteejay.com/images/ayeteejay.svg" width="150">
</p>
