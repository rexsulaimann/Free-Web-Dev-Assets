# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Getting started with the footer component
This footer component is completely responsive and designed using Css-Grids.
## Available Scripts

In the project directory, you can run:

### `npm install`

Download & copy the folder in your project directory and runthe above command.
It will update and install all the needed node dependencies. 


### `npm start`

Runs the app(footer component) in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.




