import React from "react";
import  {FooterContainer} from "./components/footer/container/footer";

function App() {
  return (
    <>
      <FooterContainer/>
    </>
  );
}

export default App;
