<p align="center">
© Dilshad Noshad, <a href="https://github.com/DilshadNoshad">Github Profile</a>
<p align="center">
<img src="https://i.ibb.co/h1YhQG3/site-logo-D.png" width="150">
</p>

## Screenshots

Initially, the navbar looks like (www.mobileworldlive.com):

<p align="left">
<img src="img/real.png" width="600">
</p>

## Live Demo

<p align="left">
<a href="https://dilshadnoshad.github.io/MobileWorldLive-Navbar/">
<img src="img/my_vers_d.png" width="600"></a>
</p>
