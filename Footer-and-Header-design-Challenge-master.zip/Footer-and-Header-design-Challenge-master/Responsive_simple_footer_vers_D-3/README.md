# Responsive_simple_footer_vers_D-3

## 💻 D-vers

<br>

![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)

<br>

# Screenshot

![screenshot](simple_footer.png)

<br>

# Live Preview

Url https://dilshadnoshad.github.io/Simple_footer_version-0/

<br>

## Happy Coding!
