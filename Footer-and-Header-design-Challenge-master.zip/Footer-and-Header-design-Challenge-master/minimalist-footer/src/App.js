import Footer from './components/Footer.js';

function App() {
  return (
    <div>
      <Footer />
    </div>
  );
}

export default App;
