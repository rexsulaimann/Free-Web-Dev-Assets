# Contoh Crud (Create Read Update Delete) Antara PHP dan MySQL
Langkah yang perlu dilakukan
1. Import file akademik.sql ke database yang kamu punya
2. Atur koneksi ke file index.php
3. Doakan yang terbaik bagi saya dan keluarga saya :) 
